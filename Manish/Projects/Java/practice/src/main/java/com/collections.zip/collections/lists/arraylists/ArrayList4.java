package com.collections.lists.arraylists;

import java.util.ArrayList;

public class ArrayList4 {
    public static void main(String[] args) {
        ArrayList<String> al = new ArrayList<String>();
        al.add("a1");
        al.add("a2");
        al.add("a3");
        al.add("a4");

        System.out.println(al);
    }
}
