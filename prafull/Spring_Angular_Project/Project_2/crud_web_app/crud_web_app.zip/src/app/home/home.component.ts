import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  mystatus: any = 0
  submitted:boolean= false;

  constructor(private fb: FormBuilder,private user:UserService) { }

  loginForm = new FormGroup({
    username: new FormControl('', [Validators.required,
      Validators.maxLength(15),
      Validators.pattern(/^[a-zA-Z]*$/)]),
    password:new FormControl('',[Validators.required,
    Validators.maxLength(20),Validators.minLength(8),
    Validators.pattern(/^[a-zA-Z][0-9][@$#*&?_!]*$/)])  
  })

  onSubmit(loginForm:any) {
    this.user.saveUser(loginForm.value).subscribe((res)=>{
    this.mystatus=res.status
    console.log(this.mystatus);
    loginForm=true;
    this.loginForm;
    })
    this.submitted = true;
  }

  get username():FormControl{
    return this.loginForm.get("username") as FormControl;
  }
  get password():FormControl{
    return this.loginForm.get("password") as FormControl;
  }
}
