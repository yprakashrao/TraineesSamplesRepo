import { Component } from '@angular/core';
import { FormBuilder,FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../user.service';


@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent {
  
  mystatus: any = 0 
  submitted = false;
  constructor(private fb: FormBuilder,private user: UserService) { }


  registerForm = new FormGroup({

    fullname: new FormControl('', [Validators.required, Validators.minLength(2),
    Validators.maxLength(20),
    Validators.pattern(/^[a-zA-Z]*$/)]),

    username: new FormControl('', [Validators.required, Validators.minLength(2),
    Validators.maxLength(15),  
    Validators.pattern(/^[a-zA-Z]*$/)]),

    password:new FormControl('',[Validators.required,
    Validators.maxLength(20),Validators.minLength(8),
    Validators.pattern(/^[a-zA-Z][0-9][@$#*&?_!]*$/)]),

    phonenumber: new FormControl('', [Validators.required,
    Validators.pattern(/^[0-9]*$/),
    Validators.minLength(10),
    Validators.maxLength(10)]),

    gender: new FormControl('', [Validators.required])
  })

  
  onSubmit(form: any) {
      this.user.saveUser(form.value).subscribe((res) => {
      this.mystatus = res.status
      console.log(this.mystatus);
      form = true;
    })
  }

  get fullname(): FormControl {
    return this.registerForm.get("fullname") as FormControl;
  }
  get username(): FormControl {
    return this.registerForm.get("username") as FormControl;
  }
  get password(): FormControl {
    return this.registerForm.get("password") as FormControl;
  }
  get phone(): FormControl {
    return this.registerForm.get("phonenumber") as FormControl;
  }
  get gender(): FormControl {
    return this.registerForm.get("gender") as FormControl;
  }
  
}
