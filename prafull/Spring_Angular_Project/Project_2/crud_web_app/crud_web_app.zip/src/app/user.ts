export class User{
    username:string;
    fullname:string;
    phonenumber:number;
    password:string;
    gender:string;
    
}