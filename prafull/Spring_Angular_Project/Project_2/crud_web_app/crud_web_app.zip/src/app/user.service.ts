import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";


@Injectable({
    providedIn:'root'
})

export class UserService{

 constructor(private http:HttpClient){}

  getUserList(){
    const baseUrl = 'http://localhost:8080/user/users';
    return this.http.get<any>(baseUrl);
  }

  loginUser(username:string,password:string){
    const baseUrl = 'http://localhost:8080/user/login/'+username+'/'+password;
    return this.http.get<any>(baseUrl);
  }

  saveUser(user:any){
    const baseUrl = 'http://localhost:8080/user/save';
    return this.http.post<any>(baseUrl,user);
  }

  deleteUser(){
    const baseUrl = 'http://localhost:8080/user/delete/{id}';
    return this.http.delete<any>(baseUrl)
  }

  updateUser(){
    const baseUrl = 'http://localhost:8080/user/update/{id}';
    return this.http.put<any>(baseUrl,this.updateUser)
  }
 
}