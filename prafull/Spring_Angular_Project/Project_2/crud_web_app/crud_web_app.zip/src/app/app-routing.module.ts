import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from 'angular-bootstrap-md';
import { RegisterFormComponent } from './register-form/register-form.component';
import { FooterComponent } from './footer/footer.component';
import { UserlistComponent } from './userlist/userlist.component';



const routes: Routes = [
  { path: '',component:HomeComponent},
  { path: 'app-navbar',component:NavbarComponent},
  { path: 'register-form', component: RegisterFormComponent },  
  { path: 'app-footer',component:FooterComponent},
  { path: 'userlist',component:UserlistComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
